// ==UserScript==
// @name         知乎排版优化
// @namespace    https://www.zhihu.com/
// @version      1.2
// @description  知乎排版优化!
// @author       chenglinz <onepiece8971@163.com>
// @match        https://www.zhihu.com/question/*
// @match        https://www.zhihu.com/people/*
// @match        https://www.zhihu.com/topic/*
// @match        https://www.zhihu.com/search?*
// @match        https://www.zhihu.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    var path = location.pathname.slice(0);
    (function (){
        if (path == '/') {
            var selectInner = document.querySelector('.zm-side-section-inner').querySelector(".zm-side-nav-group");
            var rightInner = document.createElement("div");
            rightInner.className='zu-main-sidebar';
            rightInner.style.width = '110px';
            rightInner.style.marginLeft = '-130px';
            rightInner.appendChild(selectInner);
            var zuMain = document.querySelector('.zu-main');
            zuMain.appendChild(rightInner);
        }
    })();
    (function (){
        if (path.match(/\/question\/\d+/g)) {
            var re = document.querySelector('.Question-sideColumn');
            re.remove();
            var inner = document.querySelector('.Question-mainColumn');
            inner.style.marginLeft = '155px';
        }
    })();
    (function (){
        if (path.match(/\/topic\/.*/g)) {
            var selectInner = document.querySelector('.zm-side-section-inner').getElementsByTagName("a")[0];
            selectInner.style.marginBottom = '30px';
            var rightInner = document.createElement("div");
            rightInner.className='zu-main-sidebar';
            rightInner.style.width = '110px';
            rightInner.style.marginLeft = '-130px';
            rightInner.appendChild(selectInner);
            rightInner.appendChild(document.querySelector('div.zu-main-sidebar > div:nth-child(2)'));
            rightInner.appendChild(document.getElementById('zh-topic-side-parents-list'));
            rightInner.appendChild(document.getElementById('zh-topic-side-children-list'));
            var zuMain = document.querySelector('.zu-main');
            zuMain.appendChild(rightInner);
        }
    })();
    (function (){
        if (path.match(/\/people\/.*/g)) {
            var right = document.querySelector('.Profile-sideColumn');
            var selectInner = right.querySelector('.Profile-footerOperations');
            while(right.hasChildNodes()) {
                right.removeChild(right.firstChild);
            }
            right.style.width = '145px';
            right.appendChild(selectInner);
            var inner = document.querySelector('.Profile-mainColumn');
            inner.style.marginLeft = '155px';
        }
    })();
    // 只应用到主页,问题页,话题页,搜索页
    if (path == '/' || path.match(/\/question\/\d+/g) || path.match(/\/topic\/.*/g) || path.match(/\/search?.*/g)) {
        var re = document.querySelector('.zu-main-sidebar');
        re.remove();
        var inner = document.querySelector('.zu-main-content-inner');
        inner.style.marginLeft = '150px';
        inner.style.marginRight = '150px';
        var backtotop = document.querySelector('.zh-backtotop');
        backtotop.style.marginLeft = '350px';
    }
    //document.body.style.cssText = "-webkit-transform:scale(1.1)";
})();